74ls164.o: 74LS164.c
74ls164.o: defines.h
74ls164.o: delays.h
74ls164.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
