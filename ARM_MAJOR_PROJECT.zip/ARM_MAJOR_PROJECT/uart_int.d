uart_int.o: UART_INT.c
uart_int.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.H
uart_int.o: C:\KeilARM\ARM\RV31\INC\string.h
uart_int.o: types.h
uart_int.o: spi.h
uart_int.o: spi_eeprom.h
uart_int.o: spi_eeprom_defines.h
