main.o: main.c
main.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.H
main.o: C:\KeilARM\ARM\RV31\INC\string.h
main.o: delays.h
main.o: defines.h
main.o: 74LS164.h
main.o: dml.h
