spi_eeprom.o: spi_eeprom.c
spi_eeprom.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
spi_eeprom.o: types.h
spi_eeprom.o: spi_defines.h
spi_eeprom.o: spi.h
spi_eeprom.o: spi_eeprom_defines.h
spi_eeprom.o: spi_eeprom.h
spi_eeprom.o: delay.h
